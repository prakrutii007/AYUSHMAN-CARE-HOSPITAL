import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { User, Lock, Menu, X, Stethoscope } from 'lucide-react';
import Home from './pages/Home';
import PatientPortal from './pages/PatientPortal';
import Appointments from './pages/Appointments';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showLoginForm, setShowLoginForm] = useState(false);

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white">
        {/* Navigation Bar */}
        <nav className="bg-white shadow-md border-t-4 border-orange-500">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <Link to="/" className="flex items-center">
                  <Stethoscope className="h-8 w-8 text-orange-600" />
                  <span className="ml-2 text-xl font-semibold text-gray-900">आयुष्मान Care</span>
                </Link>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center space-x-4">
                <Link to="/" className="px-3 py-2 rounded-md text-gray-600 hover:text-orange-600">Home</Link>
                <Link to="/patient-portal" className="px-3 py-2 rounded-md text-gray-600 hover:text-orange-600">Patient Portal</Link>
                <Link to="/appointments" className="px-3 py-2 rounded-md text-gray-600 hover:text-orange-600">Book Appointment</Link>
                <button
                  onClick={() => setShowLoginForm(!showLoginForm)}
                  className="flex items-center px-4 py-2 rounded-md text-gray-600 hover:text-orange-600 transition-colors"
                >
                  <User className="h-5 w-5 mr-2" />
                  Login
                </button>
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden flex items-center">
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="text-gray-600 hover:text-orange-600"
                >
                  {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                </button>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1">
                <Link to="/" className="block px-3 py-2 rounded-md text-gray-600 hover:text-orange-600">Home</Link>
                <Link to="/patient-portal" className="block px-3 py-2 rounded-md text-gray-600 hover:text-orange-600">Patient Portal</Link>
                <Link to="/appointments" className="block px-3 py-2 rounded-md text-gray-600 hover:text-orange-600">Book Appointment</Link>
                <button
                  onClick={() => setShowLoginForm(!showLoginForm)}
                  className="flex items-center w-full px-3 py-2 rounded-md text-gray-600 hover:text-orange-600 transition-colors"
                >
                  <User className="h-5 w-5 mr-2" />
                  Login
                </button>
              </div>
            </div>
          )}

          {/* Login Form Popup */}
          {showLoginForm && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg p-6 w-full max-w-md">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold text-gray-900">Welcome Back</h2>
                  <button
                    onClick={() => setShowLoginForm(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Mobile Number or Email</label>
                    <div className="mt-1 relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                        placeholder="Enter mobile number or email"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Password</label>
                    <div className="mt-1 relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Lock className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="password"
                        className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                        placeholder="Enter your password"
                      />
                    </div>
                    <a href="#" className="text-sm text-orange-600 hover:text-orange-700 mt-1 inline-block">Forgot password?</a>
                  </div>
                  <button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                  >
                    Login
                  </button>
                  <p className="text-center text-sm text-gray-600">
                    New user? <a href="#" className="text-orange-600 hover:text-orange-700">Register here</a>
                  </p>
                </form>
              </div>
            </div>
          )}
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/patient-portal" element={<PatientPortal />} />
          <Route path="/appointments" element={<Appointments />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;