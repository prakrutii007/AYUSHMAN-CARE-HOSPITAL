import React from 'react';
import { Star, Clock, Phone } from 'lucide-react';

function Home() {
  const doctors = [
    {
      name: "Dr. Priya Sharma",
      specialty: "General Physician",
      experience: "15+ years",
      languages: "Hindi, English",
      image: "https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Dr. Rajesh Patel",
      specialty: "Ayurveda Specialist",
      experience: "20+ years",
      languages: "Hindi, Gujarati, English",
      image: "https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      name: "Dr. Meera Reddy",
      specialty: "Family Medicine",
      experience: "12+ years",
      languages: "Telugu, English, Hindi",
      image: "https://images.pexels.com/photos/7088530/pexels-photo-7088530.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Your Health, Our Priority
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Experience the perfect blend of modern healthcare and traditional wisdom
        </p>
        <div className="flex justify-center space-x-8">
          <div className="text-center">
            <Star className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <h3 className="font-semibold">Expert Doctors</h3>
            <p className="text-gray-600">Highly qualified specialists</p>
          </div>
          <div className="text-center">
            <Clock className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <h3 className="font-semibold">24/7 Support</h3>
            <p className="text-gray-600">Round the clock care</p>
          </div>
          <div className="text-center">
            <Phone className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <h3 className="font-semibold">Easy Appointments</h3>
            <p className="text-gray-600">Book in few clicks</p>
          </div>
        </div>
      </div>

      {/* Doctors Section */}
      <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Meet Our Expert Doctors</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {doctors.map((doctor, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105">
            <img
              src={doctor.image}
              alt={doctor.name}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold text-gray-900">{doctor.name}</h3>
              <p className="text-orange-600 font-medium mt-1">{doctor.specialty}</p>
              <p className="text-gray-600 mt-2">{doctor.experience} experience</p>
              <p className="text-gray-600 text-sm mt-1">Languages: {doctor.languages}</p>
              <button className="mt-4 w-full bg-orange-600 text-white py-2 px-4 rounded-md hover:bg-orange-700 transition-colors">
                Book Appointment
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Emergency Contact */}
      <div className="mt-16 bg-orange-50 rounded-lg p-8 text-center">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">24/7 Emergency Contact</h3>
        <p className="text-xl font-semibold text-orange-600">Call: 108</p>
        <p className="text-gray-600 mt-2">For immediate medical assistance</p>
      </div>
    </div>
  );
}

export default Home;