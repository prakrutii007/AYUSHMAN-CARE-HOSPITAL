import React, { useState } from 'react';
import { FileText, Activity, Pill as Pills, Calendar } from 'lucide-react';

function PatientPortal() {
  const [activeTab, setActiveTab] = useState('records');

  const medicalRecords = [
    { date: '2024-03-15', type: 'Lab Results', doctor: 'Dr. Sarah Wilson', status: 'Completed' },
    { date: '2024-02-28', type: 'X-Ray Report', doctor: 'Dr. Michael Chen', status: 'Pending' },
    { date: '2024-02-10', type: 'Annual Checkup', doctor: 'Dr. Emily Rodriguez', status: 'Completed' },
  ];

  const medications = [
    { name: 'Amoxicillin', dosage: '500mg', frequency: 'Twice daily', startDate: '2024-03-01', endDate: '2024-03-07' },
    { name: 'Lisinopril', dosage: '10mg', frequency: 'Once daily', startDate: '2024-02-15', endDate: 'Ongoing' },
    { name: 'Metformin', dosage: '850mg', frequency: 'With meals', startDate: '2024-01-20', endDate: 'Ongoing' },
  ];

  const vitals = [
    { date: '2024-03-15', bp: '120/80', pulse: '72', temp: '98.6°F', weight: '150 lbs' },
    { date: '2024-02-28', bp: '118/78', pulse: '70', temp: '98.4°F', weight: '149 lbs' },
    { date: '2024-02-10', bp: '122/82', pulse: '74', temp: '98.7°F', weight: '151 lbs' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Patient Portal</h1>
      
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex border-b mb-6">
          <button
            className={`flex items-center px-4 py-2 border-b-2 ${
              activeTab === 'records' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500'
            }`}
            onClick={() => setActiveTab('records')}
          >
            <FileText className="h-5 w-5 mr-2" />
            Medical Records
          </button>
          <button
            className={`flex items-center px-4 py-2 border-b-2 ${
              activeTab === 'vitals' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500'
            }`}
            onClick={() => setActiveTab('vitals')}
          >
            <Activity className="h-5 w-5 mr-2" />
            Vitals
          </button>
          <button
            className={`flex items-center px-4 py-2 border-b-2 ${
              activeTab === 'medications' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500'
            }`}
            onClick={() => setActiveTab('medications')}
          >
            <Pills className="h-5 w-5 mr-2" />
            Medications
          </button>
        </div>

        {activeTab === 'records' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Doctor</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {medicalRecords.map((record, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{record.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{record.type}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{record.doctor}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        record.status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'vitals' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Blood Pressure</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pulse</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Temperature</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Weight</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {vitals.map((vital, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{vital.date}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{vital.bp}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{vital.pulse}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{vital.temp}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{vital.weight}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'medications' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Medication</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dosage</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Frequency</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Date</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {medications.map((medication, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{medication.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{medication.dosage}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{medication.frequency}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{medication.startDate}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{medication.endDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default PatientPortal;